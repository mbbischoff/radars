//
//  ViewController.m
//  FontAwesomeKitCrashDemo
//
//  Created by Sander van Tulden on 10-02-14.
//
//

#import "ViewController.h"
#import "FontAwesomeKit.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Setting up the icon and setting the image, when this is commented, I won't get the crash
    FAKFontAwesome *emailIcon = [FAKFontAwesome envelopeIconWithSize:20];
    self.emailFAIcon.image = [emailIcon imageWithSize:CGSizeMake(20, 20)];
    
    // Needed to display the text exactly within the container
    self.emailTextView.textContainer.lineFragmentPadding = 0;
    self.emailTextView.textContainerInset = UIEdgeInsetsZero;
    
    // Needed to make the link detection work instantly without first selecting text
    self.emailTextView.linkTextAttributes = @{NSForegroundColorAttributeName: [UIColor blueColor], NSUnderlineStyleAttributeName: [NSNumber numberWithInt:NSUnderlineStyleSingle]};
    self.emailTextView.text = nil;
    self.emailTextView.text = @"test@gmail.com";
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
