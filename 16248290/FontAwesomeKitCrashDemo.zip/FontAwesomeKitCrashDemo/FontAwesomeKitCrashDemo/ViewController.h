//
//  ViewController.h
//  FontAwesomeKitCrashDemo
//
//  Created by Sander van Tulden on 10-02-14.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *emailFAIcon;
@property (weak, nonatomic) IBOutlet UITextView *emailTextView;

@end
