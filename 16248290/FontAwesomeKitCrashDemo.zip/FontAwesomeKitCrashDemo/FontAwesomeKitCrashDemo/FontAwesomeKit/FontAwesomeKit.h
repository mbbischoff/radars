#ifndef FontAwesomeKit

#define FontAwesomeKit

#import "FAKIcon.h"
#import "FAKFontAwesome.h"
#import "FAKFoundationIcons.h"
#import "FAKZocial.h"
#import "FAKIonIcons.h"

#endif
